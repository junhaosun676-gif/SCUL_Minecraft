namespace SCUL;

internal static class AppInfo
{
    public const string Version = "v0.6-patch0127";
}
