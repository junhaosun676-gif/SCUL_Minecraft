using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SCUL;

public sealed class SplashForm : Form
{
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 25 };
    private float phase;
    private int ticks;

    public SplashForm()
    {
        AutoScaleMode = AutoScaleMode.None;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterScreen;
        var workArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1280, 720);
        var splashWidth = Math.Min(1000, Math.Max(560, workArea.Width - 40));
        var splashHeight = Math.Min(580, Math.Max(340, workArea.Height - 40));
        ClientSize = new Size(splashWidth, splashHeight);
        MinimumSize = new Size(480, 300);
        DoubleBuffered = true;
        BackColor = Color.FromArgb(12, 16, 27);

        timer.Tick += (_, _) =>
        {
            phase += .035f;
            ticks++;
            Invalidate();
            if (ticks >= 80)
            {
                timer.Stop();
                var main = new MainForm();

                // Keep the splash form alive as the Application.Run() owner.
                // Closing it here can end the message loop before the main window remains open.
                main.FormClosed += (_, _) => Close();
                main.Show();
                Hide();
            }
        };
        Shown += (_, _) => timer.Start();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        using var bg = new LinearGradientBrush(ClientRectangle,
            Color.FromArgb(9, 14, 29), Color.FromArgb(35, 47, 83), 18f);
        g.FillRectangle(bg, ClientRectangle);

        for (int i = 0; i < 10; i++)
        {
            float size = 130 + i * 39;
            float pulse = (float)Math.Sin(phase + i * .4f) * 11;
            using var pen = new Pen(Color.FromArgb(18 + i * 2, 83, 160, 255), 1.4f);
            var centerX = ClientSize.Width * 0.71f;
            var centerY = ClientSize.Height * 0.47f;
            var scaledSize = size * Math.Min(1f, ClientSize.Width / 1000f);
            g.DrawEllipse(pen, centerX - scaledSize / 2 - pulse, centerY - scaledSize / 2 - pulse,
                scaledSize + pulse * 2, scaledSize + pulse * 2);
        }
        for (int i = 0; i < 65; i++)
        {
            float x = (i * 151 + phase * (18 + i % 5) * 10) % (ClientSize.Width + 20);
            float y = (i * 83 + (float)Math.Sin(phase + i) * 28) % ClientSize.Height;
            using var brush = new SolidBrush(Color.FromArgb(45 + i * 3 % 100, 112, 195, 255));
            g.FillEllipse(brush, x, y, 2 + i % 3, 2 + i % 3);
        }

        using var logoFont = new Font("Segoe UI", 48, FontStyle.Bold);
        using var subtitleFont = new Font("Segoe UI", 15);
        using var smallFont = new Font("Segoe UI", 10);
        using var white = new SolidBrush(Color.White);
        using var blue = new SolidBrush(Color.FromArgb(110, 195, 255));
        using var muted = new SolidBrush(Color.FromArgb(180, 198, 226));
        g.DrawString("SCUL", logoFont, white, ClientSize.Width * 0.075f, ClientSize.Height * 0.29f);
        g.DrawString("SUPER CRAFT ULTIMATE LAUNCHER", subtitleFont, blue, ClientSize.Width * 0.083f, ClientSize.Height * 0.425f);
        g.DrawString("Your worlds. Your way.", subtitleFont, muted, ClientSize.Width * 0.083f, ClientSize.Height * 0.50f);
        using var track = new SolidBrush(Color.FromArgb(55, 255, 255, 255));
        using var progress = new SolidBrush(Color.FromArgb(74, 159, 255));
        g.FillRectangle(track, ClientSize.Width * 0.083f, ClientSize.Height * 0.836f, ClientSize.Width * 0.83f, 6);
        g.FillRectangle(progress, ClientSize.Width * 0.083f, ClientSize.Height * 0.836f, (int)(ClientSize.Width * 0.83f * Math.Min(1, ticks / 80f)), 6);
        g.DrawString("LOADING SCUL", smallFont, muted, ClientSize.Width * 0.083f, ClientSize.Height - 54);
        var versionText = AppInfo.Version + " PREVIEW";
        var versionSize = g.MeasureString(versionText, smallFont);
        var baselineY = ClientSize.Height - 54;
        g.DrawString(versionText, smallFont, muted,
            Math.Max(24, ClientSize.Width - versionSize.Width - 70), baselineY);
    }
}
