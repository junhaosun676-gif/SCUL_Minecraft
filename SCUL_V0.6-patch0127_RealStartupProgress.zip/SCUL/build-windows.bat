@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK was not found.
  echo Install it from: https://dotnet.microsoft.com/download/dotnet/8.0
  echo Then run this file again.
  pause
  exit /b 1
)
dotnet publish SCUL.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true ^
  -o publish
if errorlevel 1 (
  echo.
  echo Build failed. Read the errors above.
  pause
  exit /b 1
)
echo.
echo Build successful. EXE location:
echo %~dp0publish\SCUL.exe
pause
