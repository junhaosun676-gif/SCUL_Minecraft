using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SCUL;

/// <summary>
/// Reports progress from actual startup work. Call ReportStep only after a real
/// initialization task has completed; do not use a timer to fake completion.
/// </summary>
internal sealed class StartupProgress
{
    private readonly IProgress<StartupProgressUpdate> _progress;
    private readonly int _totalSteps;
    private int _completedSteps;

    public StartupProgress(IProgress<StartupProgressUpdate> progress, int totalSteps)
    {
        _progress = progress ?? throw new ArgumentNullException(nameof(progress));
        if (totalSteps <= 0) throw new ArgumentOutOfRangeException(nameof(totalSteps));
        _totalSteps = totalSteps;
    }

    public async Task RunStepAsync(string stepName, Func<Task> action)
    {
        if (action == null) throw new ArgumentNullException(nameof(action));
        _progress.Report(new StartupProgressUpdate(stepName, _completedSteps, _totalSteps, false));
        await action().ConfigureAwait(false);
        _completedSteps++;
        _progress.Report(new StartupProgressUpdate(stepName, _completedSteps, _totalSteps, true));
    }
}

internal sealed record StartupProgressUpdate(string StepName, int CompletedSteps, int TotalSteps, bool StepCompleted)
{
    public int Percent => Math.Clamp((int)Math.Round(CompletedSteps * 100.0 / TotalSteps), 0, 100);
}
