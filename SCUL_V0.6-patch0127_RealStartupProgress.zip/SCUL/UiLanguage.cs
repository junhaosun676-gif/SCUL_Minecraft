using System;
using System.Globalization;
using System.Windows.Forms;

namespace SCUL;

internal static class UiLanguage
{
    public static bool IsChinese { get; } = DetectChinese();

    private static bool DetectChinese()
    {
        try
        {
            var culture = CultureInfo.CurrentUICulture;
            if (culture.TwoLetterISOLanguageName.Equals("zh", StringComparison.OrdinalIgnoreCase))
                return true;

            var userCulture = CultureInfo.CurrentCulture;
            return userCulture.TwoLetterISOLanguageName.Equals("zh", StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return false;
        }
    }

    public static string Choose(string chinese, string english) => IsChinese ? chinese : english;

    // Applies translations to common, exact-match UI labels. Unknown text is left unchanged.
    public static void Apply(Control root)
    {
        if (IsChinese || root == null) return;
        TranslateTree(root);
    }

    private static void TranslateTree(Control control)
    {
        if (Translations.TryGetValue(control.Text, out var translated))
            control.Text = translated;

        foreach (Control child in control.Controls)
            TranslateTree(child);
    }

    private static readonly System.Collections.Generic.Dictionary<string, string> Translations =
        new(StringComparer.Ordinal)
        {
            ["主页"] = "Home",
            ["游戏实例"] = "Game Instances",
            ["Java 环境"] = "Java Environment",
            ["多人联机"] = "Multiplayer",
            ["账号登录"] = "Account Login",
            ["日志与诊断"] = "Logs & Diagnostics",
            ["版本与启动"] = "Versions & Launch",
            ["设置"] = "Settings",
            ["独立启动器项目"] = "Standalone Launcher Project",
            ["欢迎使用 SCUL"] = "Welcome to SCUL",
            ["游戏实例管理"] = "Game Instance Management",
            ["Java 环境检测"] = "Java Environment Check",
            ["多人游戏"] = "Multiplayer",
            ["账号与登录"] = "Account & Login",
            ["日志与诊断"] = "Logs & Diagnostics",
            ["版本与启动设置"] = "Version & Launch Settings",
            ["应用设置"] = "Application Settings",
            ["刷新"] = "Refresh",
            ["添加"] = "Add",
            ["删除"] = "Delete",
            ["保存"] = "Save",
            ["取消"] = "Cancel",
            ["确定"] = "OK",
            ["浏览"] = "Browse",
            ["检测 Java"] = "Detect Java",
            ["选择 java.exe"] = "Select java.exe",
            ["启动游戏"] = "Launch Game",
            ["复制"] = "Copy",
            ["清空"] = "Clear",
            ["打开目录"] = "Open Folder",
            ["返回"] = "Back",
            ["下一步"] = "Next",
            ["上一步"] = "Previous",
            ["语言"] = "Language",
            ["自动"] = "Auto",
            ["中文"] = "Chinese",
            ["英文"] = "English",
            ["未检测到 Java"] = "Java was not detected",
            ["检测成功"] = "Detection successful",
            ["检测失败"] = "Detection failed",
            ["尚未选择实例"] = "No instance selected",
            ["名称"] = "Name",
            ["路径"] = "Path",
            ["状态"] = "Status",
            ["版本"] = "Version",
            ["服务器地址"] = "Server Address",
            ["Java 路径"] = "Java Path",
            ["选择游戏目录"] = "Select Game Directory",
            ["登录 Microsoft 账号"] = "Sign in with Microsoft",
            ["退出登录"] = "Sign Out",
            ["尚未登录"] = "Not signed in",
            ["已登录"] = "Signed in",
            ["检查更新"] = "Check for Updates",
            ["关于 SCUL"] = "About SCUL",
        };
}
