using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Net.Http;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace SCUL;

public sealed class MainForm : Form
{
    private const string SculVersion = AppInfo.Version;
    private readonly Panel content = new();
    private readonly Label status = new();
    private readonly string dataDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SCUL");
    private readonly string instancesFile;
    private ListBox instanceList = new();
    private TextBox instancePath = new();
    private TextBox instanceName = new();
    private TextBox javaPath = new();
    private TextBox javaResult = new();
    private TextBox serverAddress = new();
    private TextBox logBox = new();
    private string currentPage = "主页";
    private readonly string authConfigFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SCUL", "auth-config.json");
    private readonly string authStateFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SCUL", "auth-state.json");

    private static readonly Color Bg = Color.FromArgb(15, 19, 29);
    private static readonly Color Side = Color.FromArgb(19, 24, 36);
    private static readonly Color Card = Color.FromArgb(27, 34, 48);
    private static readonly Color Blue = Color.FromArgb(40, 119, 245);
    private static readonly Color TextMuted = Color.FromArgb(165, 182, 207);

    public MainForm()
    {
        Shown += (_, _) => UiLanguage.Apply(this);

        Directory.CreateDirectory(dataDir);
        instancesFile = Path.Combine(dataDir, "instances.json");

        Text = "SCUL — Super Craft Ultimate Launcher";
        StartPosition = FormStartPosition.CenterScreen;
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96F, 96F);
        // Keep the launcher usable on smaller displays; the available work area
        // determines the minimum instead of forcing a fixed 900x620 window.
        var workArea = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1280, 720);
        MinimumSize = new Size(Math.Min(760, Math.Max(560, workArea.Width - 40)),
            Math.Min(520, Math.Max(420, workArea.Height - 40)));
        Size = new Size(Math.Min(1480, Math.Max(900, workArea.Width)),
            Math.Min(920, Math.Max(620, workArea.Height)));
        WindowState = FormWindowState.Maximized;
        BackColor = Bg;
        ForeColor = Color.White;
        Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
        KeyPreview = true;

        var shell = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Bg };
        var sidebarWidth = Math.Clamp((int)(workArea.Width * 0.16), 168, 250);
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, sidebarWidth));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        Controls.Add(shell);

        var sidebar = new Panel { Dock = DockStyle.Fill, BackColor = Side, Padding = new Padding(16) };
        shell.Controls.Add(sidebar, 0, 0);
        sidebar.Controls.Add(new Label
        {
            Text = "◆  SCUL", Dock = DockStyle.Top, Height = 76,
            Font = new Font("Microsoft YaHei UI", 23F, FontStyle.Bold, GraphicsUnit.Point), ForeColor = Color.FromArgb(117, 185, 255),
            TextAlign = ContentAlignment.MiddleLeft
        });

        var nav = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill, AutoScroll = true, FlowDirection = FlowDirection.TopDown,
            WrapContents = false, BackColor = Side
        };
        sidebar.Controls.Add(nav);
        foreach (var page in new[] { "主页", "游戏实例", "Java 环境", "多人联机", "账号登录", "日志与诊断", "版本与启动", "设置" })
            nav.Controls.Add(CreateNav(page));

        sidebar.Controls.Add(new Label
        {
            Text = $"SCUL {SculVersion} PREVIEW\r\n独立启动器项目",
            Dock = DockStyle.Bottom, Height = 66, ForeColor = Color.Gray,
            TextAlign = ContentAlignment.BottomLeft, Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular, GraphicsUnit.Point)
        });

        var right = new Panel { Dock = DockStyle.Fill, BackColor = Bg, Padding = new Padding(22, 16, 22, 12) };
        shell.Controls.Add(right, 1, 0);

        var top = new Panel { Dock = DockStyle.Top, Height = 58, BackColor = Bg };
        right.Controls.Add(top);
        var pageTitle = new Label
        {
            Name = "PageTitle", Text = "游戏主页", Dock = DockStyle.Left, Width = 420, AutoEllipsis = true,
            Font = new Font("Microsoft YaHei UI", 19F, FontStyle.Bold, GraphicsUnit.Point), TextAlign = ContentAlignment.MiddleLeft
        };
        top.Controls.Add(pageTitle);

        var account = MakeButton("账号登录", Color.FromArgb(42, 51, 70), 176);
        account.AutoEllipsis = false;
        account.TextAlign = ContentAlignment.MiddleCenter;
        account.Padding = new Padding(8, 0, 8, 0);
        account.Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
        account.Dock = DockStyle.Right;
        account.Click += (_, _) => LoadPage("账号登录");
        top.Controls.Add(account);

        content.Dock = DockStyle.Fill;
        content.BackColor = Bg;
        right.Controls.Add(content);
        content.BringToFront();
        top.BringToFront();

        status.Dock = DockStyle.Bottom;
        status.Height = 36;
        status.Text = "● 就绪  |  账号：未登录  |  游戏授权：未验证";
        status.ForeColor = TextMuted;
        status.TextAlign = ContentAlignment.MiddleLeft;
        right.Controls.Add(status);
        status.BringToFront();

        LoadPage("主页");
        FormClosed += (_, _) => { };
    }

    private Button CreateNav(string page)
    {
        var b = new Button
        {
            Text = "   " + page, Width = 208, Height = 49, TextAlign = ContentAlignment.MiddleLeft,
            FlatStyle = FlatStyle.Flat, BackColor = Side, ForeColor = Color.FromArgb(190, 204, 226),
            Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point), Margin = new Padding(0, 4, 0, 4), Cursor = Cursors.Hand
        };
        b.FlatAppearance.BorderSize = 0;
        b.Click += (_, _) => LoadPage(page);
        return b;
    }

    private void LoadPage(string page)
    {
        currentPage = page;
        content.Controls.Clear();
        var title = Controls.Find("PageTitle", true).FirstOrDefault() as Label;
        if (title != null) title.Text = page == "主页" ? "游戏主页" : page;

        switch (page)
        {
            case "主页": BuildHome(); break;
            case "游戏实例": BuildInstances(); break;
            case "Java 环境": BuildJava(); break;
            case "多人联机": BuildMultiplayer(); break;
            case "账号登录": BuildAccountLogin(); break;
            case "日志与诊断": BuildLogs(); break;
            case "版本与启动": BuildVersionLaunch(); break;
            default: BuildSettings(); break;
        }
    }

    private void BuildHome()
    {
        var layout = new TableLayoutPanel {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, BackColor = Bg,
            Padding = new Padding(0, 6, 0, 0), GrowStyle = TableLayoutPanelGrowStyle.FixedSize,
            AutoSize = false
        };
        // Proportional rows adapt to the usable client area at 100–200% scaling.
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 22F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 18F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 56F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 4F));
        content.Controls.Add(layout);

        var hero = new HeroPanel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 0, 10) };
        layout.Controls.Add(hero, 0, 0);

        var cards = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, Margin = new Padding(0, 0, 0, 10), Padding = new Padding(0) };
        for (int i = 0; i < 3; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
        layout.Controls.Add(cards, 0, 1);
        AddActionCard(cards, 0, "游戏实例", "添加并管理本地游戏目录", "打开实例管理", (_, _) => LoadPage("游戏实例"));
        AddActionCard(cards, 1, "Java 环境", "检测本机 Java 安装", "检测 Java", (_, _) => { LoadPage("Java 环境"); });
        AddActionCard(cards, 2, "多人联机", "保存常用服务器地址", "管理服务器", (_, _) => LoadPage("多人联机"));

        var bottom = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        layout.Controls.Add(bottom, 0, 2);
        bottom.Controls.Add(InfoCard("当前版本功能", "✓ 启动画面与主页\r\n✓ 本地实例目录登记\r\n✓ Java 环境检测\r\n✓ 服务器地址保存\r\n✓ 日志与基础诊断"), 0, 0);
        bottom.Controls.Add(InfoCard("尚未接入的功能", "• Microsoft / Minecraft 正版认证\r\n• 游戏本体下载与安装\r\n• 自动识别版本并生成完整启动参数\r\n• 好友邀请与远程中继服务"), 1, 0);

        var foot = new Label { Text = "SCUL 是独立项目，与 Mojang Studios / Microsoft 无官方关联。", Dock = DockStyle.Fill, ForeColor = Color.Gray, TextAlign = ContentAlignment.MiddleLeft };
        layout.Controls.Add(foot, 0, 3);
    }

    private void BuildInstances()
    {
        var outer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(0, 10, 0, 0) };
        outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44));
        outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 56));
        content.Controls.Add(outer);
        var left = NewCard();
        outer.Controls.Add(left, 0, 0);
        left.Controls.Add(Heading("本地游戏实例"));
        instanceList = new ListBox { Dock = DockStyle.Fill, BackColor = Card, ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point), IntegralHeight = false };
        left.Controls.Add(instanceList);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 72, AutoScroll = true, WrapContents = true };
        left.Controls.Add(buttons);
        buttons.Controls.Add(MakeButton("添加目录", Blue, 120));
        ((Button)buttons.Controls[0]).Click += (_, _) => PickInstance();
        var refresh = MakeButton("重新加载", Color.FromArgb(53, 65, 87), 120);
        refresh.Click += (_, _) => RefreshInstances();
        buttons.Controls.Add(refresh);

        var right = NewCard();
        outer.Controls.Add(right, 1, 0);
        right.Controls.Add(Heading("添加 / 查看实例"));
        right.Controls.Add(FieldLabel("实例名称"));
        instanceName = NewTextBox("例如：我的生存世界");
        right.Controls.Add(instanceName);
        right.Controls.Add(FieldLabel("游戏目录"));
        instancePath = NewTextBox("选择包含 versions、libraries 等目录的游戏文件夹");
        right.Controls.Add(instancePath);
        var pick = MakeButton("浏览目录…", Color.FromArgb(52, 64, 87), 150);
        pick.Click += (_, _) => PickInstance();
        right.Controls.Add(pick);
        var save = MakeButton("保存实例", Blue, 150);
        save.Click += (_, _) => SaveInstance();
        right.Controls.Add(save);
        var open = MakeButton("打开目录", Color.FromArgb(52, 64, 87), 150);
        open.Click += (_, _) => OpenSelectedInstance();
        right.Controls.Add(open);
        var note = new Label { Dock = DockStyle.Top, Height = 100, ForeColor = TextMuted, Text = "此版本只登记本地目录，不会下载游戏文件或自动启动游戏。请添加你有权使用的本地安装目录。" };
        right.Controls.Add(note);
        RefreshInstances();
    }

    private void BuildJava()
    {
        var card = NewCard();
        content.Controls.Add(card);
        card.Controls.Add(Heading("Java 环境检测"));
        card.Controls.Add(new Label
        {
            Text = "留空时尝试使用 PATH 中的 java；也可以选择 java.exe 或填写其完整路径。检测不会自动下载或安装 Java。",
            Dock = DockStyle.Top, Height = 58, ForeColor = TextMuted, AutoSize = false
        });

        javaPath = NewTextBox("");
        javaPath.Dock = DockStyle.Top;
        javaPath.Text = "";
        card.Controls.Add(javaPath);

        var buttonRow = new FlowLayoutPanel
        {
            Dock = DockStyle.Top, Height = 72, AutoSize = false,
            WrapContents = true, FlowDirection = FlowDirection.LeftToRight,
            BackColor = Card, Padding = new Padding(0, 6, 0, 6)
        };
        var detect = MakeButton("检测 Java 版本", Blue, 180);
        detect.Click += (_, _) => DetectJava();
        var browse = MakeButton("选择 java.exe", Color.FromArgb(52, 64, 87), 180);
        browse.Click += (_, _) =>
        {
            using var dlg = new OpenFileDialog
            {
                Filter = "java.exe|java.exe|Executable|*.exe|All files|*.*",
                Title = "选择 java.exe",
                CheckFileExists = true,
                Multiselect = false
            };
            if (dlg.ShowDialog(this) == DialogResult.OK)
                javaPath.Text = dlg.FileName;
        };
        buttonRow.Controls.Add(detect);
        buttonRow.Controls.Add(browse);
        card.Controls.Add(buttonRow);

        javaResult = new TextBox
        {
            Dock = DockStyle.Top, Height = 170, Multiline = true, ReadOnly = true,
            ScrollBars = ScrollBars.Vertical, WordWrap = true,
            BackColor = Color.FromArgb(12, 16, 25), ForeColor = Color.Gainsboro,
            BorderStyle = BorderStyle.FixedSingle,
            Font = new Font("Consolas", 10F),
            Text = "尚未检测。点击“检测 Java 版本”查看实际结果。"
        };
        card.Controls.Add(javaResult);
    }

    private void BuildMultiplayer()
    {
        var card = NewCard();
        content.Controls.Add(card);
        card.Controls.Add(Heading("多人联机 / 服务器列表"));
        card.Controls.Add(new Label { Text = "保存你常用的服务器地址。此功能不会创建中继或绕过服务器自身的身份验证。", Dock = DockStyle.Top, Height = 52, ForeColor = TextMuted });
        serverAddress = NewTextBox("服务器地址，例如 play.example.net:25565");
        card.Controls.Add(serverAddress);
        var save = MakeButton("保存服务器地址", Blue, 190);
        save.Click += (_, _) =>
        {
            var value = serverAddress.Text.Trim();
            if (string.IsNullOrWhiteSpace(value) || value.Contains("例如")) { ShowNotice("请先输入服务器地址。"); return; }
            var path = Path.Combine(dataDir, "servers.txt");
            var lines = File.Exists(path) ? File.ReadAllLines(path).ToList() : new System.Collections.Generic.List<string>();
            if (!lines.Contains(value, StringComparer.OrdinalIgnoreCase)) lines.Add(value);
            File.WriteAllLines(path, lines);
            ShowNotice("服务器地址已保存到本地列表。");
            LoadPage("多人联机");
        };
        card.Controls.Add(save);
        var list = new ListBox { Dock = DockStyle.Fill, BackColor = Card, ForeColor = Color.White, Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point), BorderStyle = BorderStyle.FixedSingle };
        var serverFile = Path.Combine(dataDir, "servers.txt");
        if (File.Exists(serverFile)) list.Items.AddRange(File.ReadAllLines(serverFile).Where(x => !string.IsNullOrWhiteSpace(x)).Cast<object>().ToArray());
        card.Controls.Add(list);
        var remove = MakeButton("删除选中地址", Color.FromArgb(155, 55, 65), 170);
        remove.Click += (_, _) =>
        {
            if (list.SelectedItem == null) return;
            var remaining = list.Items.Cast<string>().Where(x => x != list.SelectedItem.ToString()).ToArray();
            File.WriteAllLines(serverFile, remaining);
            LoadPage("多人联机");
        };
        card.Controls.Add(remove);
        var copy = MakeButton("复制地址", Color.FromArgb(52, 64, 87), 130);
        copy.Click += (_, _) => { if (list.SelectedItem != null) Clipboard.SetText(list.SelectedItem.ToString()!); };
        card.Controls.Add(copy);
    }

    private void BuildLogs()
    {
        var card = NewCard();
        content.Controls.Add(card);
        card.Controls.Add(Heading("日志与诊断"));
        logBox = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = Color.FromArgb(10, 13, 20), ForeColor = Color.FromArgb(190, 220, 190), Font = new Font("Consolas", 10) };
        logBox.Text = $"SCUL {SculVersion} preview{Environment.NewLine}启动时间：{DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}数据目录：{dataDir}{Environment.NewLine}授权状态：未验证（本版本未接入认证）{Environment.NewLine}";
        card.Controls.Add(logBox);
        var btn = MakeButton("复制诊断信息", Blue, 180);
        btn.Click += (_, _) => Clipboard.SetText(logBox.Text);
        card.Controls.Add(btn);
        var open = MakeButton("打开 SCUL 数据目录", Color.FromArgb(52, 64, 87), 200);
        open.Click += (_, _) => OpenPath(dataDir);
        card.Controls.Add(open);
    }


    private TextBox clientIdInput = new();

    private void BuildAccountLogin()
    {
        var layout = new TableLayoutPanel {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3,
            Padding = new Padding(0, 12, 0, 8), BackColor = Bg
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 24F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 38F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 38F));
        content.Controls.Add(layout);

        var intro = NewCard();
        intro.Padding = new Padding(26, 22, 26, 22);
        intro.Controls.Add(new Label {
            Text = "可打开 Xbox 官方网站登录账号；这只会登录浏览器，不会自动把账号授权给 SCUL。要在启动器内完成 OAuth，需要配置应用 Client ID。",
            Dock = DockStyle.Fill, ForeColor = TextMuted,
            Font = new Font("Microsoft YaHei UI", 11F, FontStyle.Regular, GraphicsUnit.Point),
            TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true
        });
        intro.Controls.Add(Heading("Microsoft / Xbox 账号登录"));
        layout.Controls.Add(intro, 0, 0);

        var config = NewCard();
        config.Padding = new Padding(26, 22, 26, 22);
        config.Controls.Add(new Label {
            Text = "应用 Client ID（需由开发者在 Microsoft Entra 管理中心注册桌面/公共客户端应用后填写）",
            Dock = DockStyle.Top, Height = 46, ForeColor = TextMuted, AutoEllipsis = true
        });
        clientIdInput = NewTextBox("粘贴应用 Client ID");
        clientIdInput.Dock = DockStyle.Top;
        clientIdInput.Height = 46;
        clientIdInput.Text = ReadClientId();
        config.Controls.Add(clientIdInput);

        var getClientId = MakeButton("打开官方页面获取 Client ID", Blue, 270);
        getClientId.Dock = DockStyle.Top;
        getClientId.Margin = new Padding(0, 12, 0, 10);
        getClientId.Click += (_, _) => {
            OpenUrl("https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade");
            ShowNotice(
                "获取 Client ID 的步骤：\r\n\r\n" +
                "1. 在 Microsoft Entra 中登录并创建应用注册。\r\n" +
                "2. 支持的帐户类型请选择包含个人 Microsoft 帐户的选项。\r\n" +
                "3. 在应用概述页复制“应用程序(客户端) ID / Application (client) ID”。\r\n" +
                "4. 在“身份验证”中配置桌面/公共客户端平台及 localhost 重定向方式。\r\n" +
                "5. 将 Client ID 粘贴回 SCUL 并保存。\r\n\r\n" +
                "只需要复制 Client ID。不要向任何人提供客户端密钥、账号密码或访问令牌。\r\n" +
                "注意：ID 格式正确不代表 Microsoft 应用配置已完成。"
            );
        };
        config.Controls.Add(getClientId);

        var save = MakeButton("保存 Client ID", Color.FromArgb(52, 64, 87), 180);
        save.Dock = DockStyle.Top;
        save.Margin = new Padding(0, 18, 0, 14);
        save.Click += (_, _) => {
            var clientId = clientIdInput.Text.Trim();
            if (!string.IsNullOrWhiteSpace(clientId) && !Guid.TryParseExact(clientId, "D", out _)) {
                ShowNotice("Client ID 格式看起来不正确。请复制完整的 Application (client) ID（通常为带连字符的 GUID），或清空后再保存。");
                return;
            }
            try {
                File.WriteAllText(authConfigFile, JsonSerializer.Serialize(new AuthConfig { ClientId = clientId }, new JsonSerializerOptions { WriteIndented = true }));
                ShowNotice(string.IsNullOrWhiteSpace(clientId)
                    ? "Client ID 已清空并保存。"
                    : "Client ID 已保存在本机 SCUL 数据目录。此操作只检查格式，不会验证 Microsoft 应用配置。");
            } catch (Exception ex) { ShowNotice("保存失败：" + ex.Message); }
        };
        config.Controls.Add(save);
        layout.Controls.Add(config, 0, 1);

        var actions = NewCard();
        actions.Padding = new Padding(26, 22, 26, 22);
        actions.Controls.Add(new Label {
            Text = "注意：完成 Microsoft 登录不等于已完成 Xbox Live / XSTS / Minecraft Profile 验证，也不代表拥有 Minecraft Java Edition 授权。当前版本仅实现 Microsoft 设备代码 OAuth 阶段。",
            Dock = DockStyle.Top, Height = 92, ForeColor = TextMuted, AutoEllipsis = true
        });
        var actionButtons = new FlowLayoutPanel {
            Dock = DockStyle.Top, Height = 148, AutoSize = false, WrapContents = true,
            FlowDirection = FlowDirection.LeftToRight, BackColor = Card,
            Padding = new Padding(0, 14, 0, 0), Margin = new Padding(0)
        };
        var xboxWeb = MakeButton("打开 Xbox 官网", Color.FromArgb(52, 64, 87), 190);
        xboxWeb.Click += (_, _) => OpenUrl("https://www.xbox.com/");
        var microsoftWeb = MakeButton("Microsoft 账号", Color.FromArgb(52, 64, 87), 190);
        microsoftWeb.Click += (_, _) => OpenUrl("https://account.microsoft.com/");
        var callbackLogin = MakeButton("浏览器登录并返回启动器", Blue, 250);
        callbackLogin.Click += async (_, _) => await StartMicrosoftLoopbackLoginAsync();
        var login = MakeButton("设备代码登录（备用）", Color.FromArgb(52, 64, 87), 220);
        login.Click += async (_, _) => await StartMicrosoftDeviceLoginAsync();
        var signout = MakeButton("清除本机登录状态", Color.FromArgb(100, 47, 55), 220);
        signout.Click += (_, _) => {
            try {
                if (File.Exists(authStateFile)) File.Delete(authStateFile);
                status.Text = "● 就绪  |  账号：未登录  |  游戏授权：未验证";
                ShowNotice("已清除本机保存的登录状态。");
            } catch (Exception ex) { ShowNotice("清除失败：" + ex.Message); }
        };
        actionButtons.Controls.Add(xboxWeb);
        actionButtons.Controls.Add(microsoftWeb);
        actionButtons.Controls.Add(callbackLogin);
        actionButtons.Controls.Add(login);
        actionButtons.Controls.Add(signout);
        actions.Controls.Add(actionButtons);
        layout.Controls.Add(actions, 0, 2);
    }

    private string ReadClientId()
    {
        try {
            if (File.Exists(authConfigFile)) return JsonSerializer.Deserialize<AuthConfig>(File.ReadAllText(authConfigFile))?.ClientId ?? "";
        } catch { }
        return "";
    }

    private async Task StartMicrosoftLoopbackLoginAsync()
    {
        var clientId = clientIdInput.Text.Trim();
        if (string.IsNullOrWhiteSpace(clientId))
        {
            ShowNotice("请先点击“打开官方页面获取 Client ID”，按提示创建 Microsoft 应用注册，再将 Application (client) ID 粘贴并保存。");
            return;
        }

        // Microsoft Entra app registration must allow the desktop/public-client
        // loopback redirect URI http://localhost:<port>/ and the consumers authority.
        var port = GetAvailableLoopbackPort();
        var redirectUri = $"http://localhost:{port}/";
        var state = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');
        var verifier = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');
        var challengeBytes = SHA256.HashData(Encoding.ASCII.GetBytes(verifier));
        var challenge = Convert.ToBase64String(challengeBytes)
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');

        try
        {
            using var listener = new HttpListener();
            listener.Prefixes.Add(redirectUri);
            listener.Start();

            var authorizeUrl = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize" +
                "?client_id=" + Uri.EscapeDataString(clientId) +
                "&response_type=code" +
                "&redirect_uri=" + Uri.EscapeDataString(redirectUri) +
                "&response_mode=query" +
                "&scope=" + Uri.EscapeDataString("XboxLive.signin offline_access") +
                "&state=" + Uri.EscapeDataString(state) +
                "&code_challenge=" + Uri.EscapeDataString(challenge) +
                "&code_challenge_method=S256";

            OpenUrl(authorizeUrl);
            using var cts = new CancellationTokenSource(TimeSpan.FromMinutes(5));
            HttpListenerContext callback;
            try
            {
                callback = await listener.GetContextAsync().WaitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                ShowNotice("等待登录回调超时，请重试。请确认 Microsoft 应用已配置 localhost 回调地址。");
                return;
            }

            var request = callback.Request;
            var response = callback.Response;
            string html;
            string? code = request.QueryString["code"];
            var returnedState = request.QueryString["state"];
            var error = request.QueryString["error"];
            if (!string.IsNullOrEmpty(error))
            {
                html = "<html><body><h2>SCUL 登录未完成</h2><p>可以关闭此窗口并返回启动器。</p></body></html>";
                response.StatusCode = 400;
            }
            else if (string.IsNullOrEmpty(code) || !CryptographicOperations.FixedTimeEquals(
                Encoding.UTF8.GetBytes(state), Encoding.UTF8.GetBytes(returnedState ?? "")))
            {
                html = "<html><body><h2>SCUL 登录回调无效</h2><p>请关闭此窗口并重新登录。</p></body></html>";
                response.StatusCode = 400;
                response.Close();
                ShowNotice("登录回调无效，state 校验失败。");
                return;
            }
            else
            {
                html = "<html><body><h2>SCUL 登录回调已收到</h2><p>可以关闭此窗口并返回 SCUL。</p></body></html>";
                response.StatusCode = 200;
            }

            var htmlBytes = Encoding.UTF8.GetBytes(html);
            response.ContentType = "text/html; charset=utf-8";
            response.ContentLength64 = htmlBytes.Length;
            await response.OutputStream.WriteAsync(htmlBytes);
            response.Close();

            if (!string.IsNullOrEmpty(error))
            {
                ShowNotice("Microsoft 登录未完成：" + error + "\r\n" + (request.QueryString["error_description"] ?? ""));
                return;
            }

            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(25) };
            using var tokenResponse = await http.PostAsync(
                "https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
                new FormUrlEncodedContent(new[]
                {
                    new System.Collections.Generic.KeyValuePair<string,string>("client_id", clientId),
                    new System.Collections.Generic.KeyValuePair<string,string>("grant_type", "authorization_code"),
                    new System.Collections.Generic.KeyValuePair<string,string>("code", code!),
                    new System.Collections.Generic.KeyValuePair<string,string>("redirect_uri", redirectUri),
                    new System.Collections.Generic.KeyValuePair<string,string>("code_verifier", verifier),
                    new System.Collections.Generic.KeyValuePair<string,string>("scope", "XboxLive.signin offline_access")
                }));
            var tokenJson = await tokenResponse.Content.ReadAsStringAsync();
            using var tokenDoc = JsonDocument.Parse(tokenJson);
            var tr = tokenDoc.RootElement;
            if (!tokenResponse.IsSuccessStatusCode || !tr.TryGetProperty("access_token", out var accessToken))
            {
                ShowNotice("Microsoft 令牌交换失败：\r\n" + tokenJson);
                return;
            }

            var stateData = new AuthState
            {
                AccessToken = accessToken.GetString() ?? "",
                TokenType = tr.TryGetProperty("token_type", out var tt) ? tt.GetString() ?? "Bearer" : "Bearer",
                ExpiresAtUtc = DateTime.UtcNow.AddSeconds(tr.TryGetProperty("expires_in", out var ei) && ei.TryGetInt32(out var sec) ? sec : 3600),
                AccountStage = "Microsoft OAuth completed; Xbox/Minecraft validation pending"
            };
            File.WriteAllText(authStateFile, JsonSerializer.Serialize(stateData, new JsonSerializerOptions { WriteIndented = true }));
            status.Text = "● Microsoft 已登录（Xbox / Minecraft 授权尚未验证）";
            ShowNotice("浏览器登录成功，已自动返回 SCUL。\r\nMicrosoft OAuth 已完成；Xbox Live、XSTS、Minecraft Profile 与 Java Edition 授权仍需后续验证。");
        }
        catch (HttpListenerException ex)
        {
            ShowNotice("无法启动本地登录回调监听器：" + ex.Message + "\r\n请确认端口未被占用，并检查应用注册中的 localhost 回调配置。");
        }
        catch (Exception ex)
        {
            ShowNotice("浏览器登录失败：" + ex.Message);
        }
    }

    private static int GetAvailableLoopbackPort()
    {
        var listener = new System.Net.Sockets.TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return port;
    }

    private async Task StartMicrosoftDeviceLoginAsync()
    {
        var clientId = clientIdInput.Text.Trim();
        if (string.IsNullOrWhiteSpace(clientId)) {
            ShowNotice("请先点击“打开官方页面获取 Client ID”，按提示创建 Microsoft 应用注册，再将 Application (client) ID 粘贴并保存。SCUL 不会使用臆造的 ID。");
            return;
        }

        try
        {
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };
            using var deviceResponse = await http.PostAsync(
                "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode",
                new FormUrlEncodedContent(new[] {
                    new System.Collections.Generic.KeyValuePair<string,string>("client_id", clientId),
                    new System.Collections.Generic.KeyValuePair<string,string>("scope", "XboxLive.signin offline_access")
                }));
            var deviceJson = await deviceResponse.Content.ReadAsStringAsync();
            if (!deviceResponse.IsSuccessStatusCode) {
                ShowNotice("Microsoft 设备代码请求失败：\r\n" + deviceJson);
                return;
            }
            using var deviceDoc = JsonDocument.Parse(deviceJson);
            var d = deviceDoc.RootElement;
            var deviceCode = d.GetProperty("device_code").GetString() ?? "";
            var userCode = d.GetProperty("user_code").GetString() ?? "";
            var verificationUri = d.TryGetProperty("verification_uri", out var uri) ? uri.GetString() ?? "https://microsoft.com/devicelogin" : "https://microsoft.com/devicelogin";
            var message = d.TryGetProperty("message", out var msg) ? msg.GetString() : null;
            OpenUrl(verificationUri);
            MessageBox.Show(this,
                (message ?? "请在浏览器中登录 Microsoft 账号并输入以下代码：") + "\r\n\r\n" + userCode,
                "Microsoft 设备代码登录", MessageBoxButtons.OK, MessageBoxIcon.Information);

            var interval = d.TryGetProperty("interval", out var iv) && iv.TryGetInt32(out var seconds) ? Math.Max(2, seconds) : 5;
            var expires = d.TryGetProperty("expires_in", out var ex) && ex.TryGetInt32(out var exp) ? exp : 900;
            var until = DateTime.UtcNow.AddSeconds(expires);
            while (DateTime.UtcNow < until)
            {
                await Task.Delay(TimeSpan.FromSeconds(interval));
                using var tokenResponse = await http.PostAsync(
                    "https://login.microsoftonline.com/consumers/oauth2/v2.0/token",
                    new FormUrlEncodedContent(new[] {
                        new System.Collections.Generic.KeyValuePair<string,string>("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
                        new System.Collections.Generic.KeyValuePair<string,string>("client_id", clientId),
                        new System.Collections.Generic.KeyValuePair<string,string>("device_code", deviceCode)
                    }));
                var tokenJson = await tokenResponse.Content.ReadAsStringAsync();
                using var tokenDoc = JsonDocument.Parse(tokenJson);
                var tr = tokenDoc.RootElement;
                if (tokenResponse.IsSuccessStatusCode && tr.TryGetProperty("access_token", out var at))
                {
                    var state = new AuthState {
                        AccessToken = at.GetString() ?? "",
                        TokenType = tr.TryGetProperty("token_type", out var tt) ? tt.GetString() ?? "Bearer" : "Bearer",
                        ExpiresAtUtc = DateTime.UtcNow.AddSeconds(tr.TryGetProperty("expires_in", out var ei) && ei.TryGetInt32(out var sec) ? sec : 3600),
                        AccountStage = "Microsoft OAuth completed; Xbox/Minecraft validation pending"
                    };
                    File.WriteAllText(authStateFile, JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }));
                    status.Text = "● Microsoft 已登录（Xbox / Minecraft 授权尚未验证）";
                    ShowNotice("Microsoft 账号登录成功。\r\n\r\n注意：此结果仅代表 Microsoft OAuth 完成；SCUL 尚未完成 Xbox Live、XSTS、Minecraft Profile 与 Java Edition 授权验证。");
                    return;
                }
                var error = tr.TryGetProperty("error", out var er) ? er.GetString() : "";
                if (error == "authorization_pending") continue;
                if (error == "slow_down") { interval += 5; continue; }
                if (error == "authorization_declined" || error == "expired_token" || error == "bad_verification_code" || error == "access_denied") {
                    ShowNotice("登录未完成：" + error);
                    return;
                }
                if (!string.IsNullOrEmpty(error)) {
                    ShowNotice("Microsoft 登录返回错误：" + error + "\r\n" + tokenJson);
                    return;
                }
            }
            ShowNotice("登录代码已过期，请重新开始。");
        }
        catch (Exception ex)
        {
            ShowNotice("Microsoft 登录流程失败：\r\n" + ex.Message);
        }
    }

    private sealed class AuthConfig { public string ClientId { get; set; } = ""; }
    private sealed class AuthState {
        public string AccessToken { get; set; } = "";
        public string TokenType { get; set; } = "Bearer";
        public DateTime ExpiresAtUtc { get; set; }
        public string AccountStage { get; set; } = "";
    }

    private void BuildVersionLaunch()
    {
        var layout = new TableLayoutPanel {
            Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3,
            Padding = new Padding(0, 12, 0, 8), BackColor = Bg,
            GrowStyle = TableLayoutPanelGrowStyle.FixedSize, AutoSize = false
        };
        // Percent-based rows prevent clipped sections at 200% DPI and other aspect ratios.
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 24F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 32F));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 44F));
        content.Controls.Add(layout);

        var intro = NewCard();
        intro.Padding = new Padding(24, 20, 24, 20);
        intro.Controls.Add(new Label {
            Text = $"{SculVersion} · 启动前检查与环境管理",
            Dock = DockStyle.Top, Height = 34, ForeColor = TextMuted,
            Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point),
            TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true
        });
        intro.Controls.Add(Heading("版本与启动中心"));
        layout.Controls.Add(intro, 0, 0);

        var checks = NewCard();
        checks.Padding = new Padding(24, 20, 24, 20);
        var buttonFlow = new FlowLayoutPanel {
            Dock = DockStyle.Fill, AutoSize = false, WrapContents = true,
            FlowDirection = FlowDirection.LeftToRight, BackColor = Card,
            Padding = new Padding(0, 14, 0, 0), Margin = new Padding(0)
        };
        var checkJava = MakeButton("检查 Java 环境", Blue, 180);
        checkJava.Click += (_, _) => LoadPage("Java 环境");
        var checkInstances = MakeButton("检查游戏目录", Color.FromArgb(52, 64, 87), 180);
        checkInstances.Click += (_, _) => LoadPage("游戏实例");
        var openData = MakeButton("打开 SCUL 数据目录", Color.FromArgb(52, 64, 87), 210);
        openData.Click += (_, _) => {
            try {
                Directory.CreateDirectory(dataDir);
                Process.Start(new ProcessStartInfo("explorer.exe", dataDir) { UseShellExecute = true });
            } catch (Exception ex) { ShowNotice("无法打开数据目录：" + ex.Message); }
        };
        buttonFlow.Controls.Add(checkJava);
        buttonFlow.Controls.Add(checkInstances);
        buttonFlow.Controls.Add(openData);
        checks.Controls.Add(buttonFlow);
        checks.Controls.Add(Heading("启动前检查"));
        layout.Controls.Add(checks, 0, 1);

        var roadmap = NewCard();
        roadmap.Padding = new Padding(24, 20, 24, 20);
        var details = new Label {
            Dock = DockStyle.Fill, ForeColor = TextMuted, AutoSize = false,
            Font = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Regular, GraphicsUnit.Point),
            Padding = new Padding(0, 12, 0, 0),
            Text = "已提供：本地实例目录登记、Java 检测、服务器地址簿、诊断日志。\\r\\n\\r\\n" +
                   "当前版本仍未提供：Microsoft 正版登录、游戏文件下载、完整游戏启动器、模组管理、好友邀请与远程中继。\\r\\n\\r\\n" +
                   "后续建议：先完成启动参数生成与启动日志，再接入官方授权流程；游戏下载仅在具备合法分发依据时实现。"
        };
        roadmap.Controls.Add(details);
        roadmap.Controls.Add(Heading("功能状态与后续计划"));
        layout.Controls.Add(roadmap, 0, 2);
    }

    private void BuildSettings()
    {
        var card = NewCard();
        content.Controls.Add(card);
        card.Controls.Add(Heading("设置"));
        card.Controls.Add(new Label { Dock = DockStyle.Top, Height = 90, ForeColor = TextMuted, Text = $"数据目录：{dataDir}\r\n窗口默认最大化。\r\n当前版本不会在后台上传日志或账号信息。" });
        var open = MakeButton("打开数据目录", Blue, 180);
        open.Click += (_, _) => OpenPath(dataDir);
        card.Controls.Add(open);
        var store = MakeButton("打开 Minecraft 官方商店", Color.FromArgb(52, 64, 87), 230);
        store.Click += (_, _) => OpenUrl("https://www.minecraft.net/store/minecraft-java-bedrock-edition-pc");
        card.Controls.Add(store);
        var about = MakeButton("关于 SCUL", Color.FromArgb(52, 64, 87), 150);
        about.Click += (_, _) => ShowNotice("SCUL — Super Craft Ultimate Launcher\r\n独立项目预览版，不代表 Mojang Studios 或 Microsoft。");
        card.Controls.Add(about);
    }

    private void PickInstance()
    {
        using var dlg = new FolderBrowserDialog { Description = "选择本地 Minecraft 游戏目录", UseDescriptionForTitle = true };
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            instancePath.Text = dlg.SelectedPath;
            if (string.IsNullOrWhiteSpace(instanceName.Text)) instanceName.Text = new DirectoryInfo(dlg.SelectedPath).Name;
        }
    }

    private void SaveInstance()
    {
        var name = instanceName.Text.Trim();
        var path = instancePath.Text.Trim();
        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(path) || !Directory.Exists(path))
        {
            ShowNotice("请填写实例名称，并选择一个存在的目录。");
            return;
        }

        var instances = ReadInstances();
        instances.RemoveAll(x => string.Equals(x.Path, path, StringComparison.OrdinalIgnoreCase));
        instances.Add(new GameInstance { Name = name, Path = path, AddedAt = DateTime.Now });
        File.WriteAllText(instancesFile, JsonSerializer.Serialize(instances, new JsonSerializerOptions { WriteIndented = true }));
        RefreshInstances();
        status.Text = $"● 已保存实例：{name}";
        ShowNotice("本地实例目录已保存。当前版本不会自动启动游戏。");
    }

    private System.Collections.Generic.List<GameInstance> ReadInstances()
    {
        try
        {
            if (!File.Exists(instancesFile)) return new();
            return JsonSerializer.Deserialize<System.Collections.Generic.List<GameInstance>>(File.ReadAllText(instancesFile)) ?? new();
        }
        catch { return new(); }
    }

    private void RefreshInstances()
    {
        if (instanceList.IsDisposed || instanceList == null) return;
        instanceList.Items.Clear();
        foreach (var item in ReadInstances()) instanceList.Items.Add(item);
        instanceList.DisplayMember = nameof(GameInstance.Display);
    }

    private void OpenSelectedInstance()
    {
        if (instanceList.SelectedItem is not GameInstance instance) { ShowNotice("请先选择一个实例。"); return; }
        OpenPath(instance.Path);
    }

    private void DetectJava()
    {
        if (javaResult != null && !javaResult.IsDisposed)
            javaResult.Text = "正在检测 Java，请稍候……";
        status.Text = "● 正在检测 Java";

        try
        {
            var configured = javaPath?.Text?.Trim() ?? "";
            string exe;

            if (string.IsNullOrWhiteSpace(configured))
            {
                // Let Windows resolve java.exe through PATH.
                exe = "java";
            }
            else if (!configured.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && !Directory.Exists(configured))
            {
                SetJavaResult("路径格式不正确：请填写 java.exe 的完整路径，或清空输入框以自动从 PATH 查找。", false);
                return;
            }
            else
            {
                configured = configured.Trim('"');
                if (Directory.Exists(configured))
                {
                    var candidate = Path.Combine(configured, "bin", "java.exe");
                    if (!File.Exists(candidate))
                    {
                        SetJavaResult("指定路径是文件夹，但其中没有 bin\\java.exe：\r\n" + candidate, false);
                        return;
                    }
                    exe = candidate;
                }
                else
                {
                    exe = configured;
                }

                if (Path.IsPathRooted(exe) && !File.Exists(exe))
                {
                    SetJavaResult("找不到指定的 Java 可执行文件：\r\n" + exe +
                        "\r\n请确认选择的是 java.exe，而不是 Java 安装目录或 javaw.exe。", false);
                    return;
                }
            }

            if (string.Equals(exe, "java", StringComparison.OrdinalIgnoreCase))
            {
                var found = FindJavaOnPath();
                if (found == null)
                {
                    SetJavaResult("未能在 PATH 或常见 Java 安装目录中找到 java.exe。HMCL 可能使用了它自带/单独指定的 Java 运行时。请在 HMCL 的设置中查看 Java 路径，然后复制该路径到这里。", false);
                    return;
                }
                exe = found;
            }

            var psi = new ProcessStartInfo
            {
                FileName = exe,
                UseShellExecute = false,
                RedirectStandardError = true,
                RedirectStandardOutput = true,
                CreateNoWindow = true,
                WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            };
            psi.ArgumentList.Add("-version");

            using var p = Process.Start(psi);
            if (p == null)
            {
                SetJavaResult("Windows 无法启动 Java 检测进程。\r\n请安装 Java，或选择 java.exe 的完整路径。", false);
                return;
            }

            var stdoutTask = p.StandardOutput.ReadToEndAsync();
            var stderrTask = p.StandardError.ReadToEndAsync();

            if (!p.WaitForExit(10000))
            {
                try { p.Kill(entireProcessTree: true); } catch { }
                SetJavaResult("检测超时：Java 在 10 秒内没有返回版本信息。\r\n可能原因：路径指向了错误程序，或 Java 安装损坏。", false);
                return;
            }

            Task.WaitAll(stdoutTask, stderrTask);
            var output = (stderrTask.Result + Environment.NewLine + stdoutTask.Result).Trim();
            if (string.IsNullOrWhiteSpace(output))
                output = "(Java 没有输出版本信息)\r\n进程退出代码：" + p.ExitCode;

            var resolvedPath = exe;
            if (string.Equals(exe, "java", StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
                    foreach (var segment in pathEnv.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
                    {
                        var candidate = Path.Combine(segment.Trim('"'), "java.exe");
                        if (File.Exists(candidate))
                        {
                            resolvedPath = candidate;
                            break;
                        }
                    }
                }
                catch { }
            }

            var success = p.ExitCode == 0;
            SetJavaResult((success ? "检测成功\r\n" : "Java 进程已运行，但返回错误\r\n") +
                "可执行文件：" + resolvedPath + "\r\n退出代码：" + p.ExitCode +
                "\r\n\r\n" + output, success);
        }
        catch (System.ComponentModel.Win32Exception ex)
        {
            SetJavaResult("未找到或无法启动 Java。\r\n请先安装兼容版本的 Java，或点击“选择 java.exe”指定路径。\r\n\r\n系统信息：" + ex.Message, false);
        }
        catch (Exception ex)
        {
            SetJavaResult("Java 检测失败：\r\n" + ex.GetType().Name + ": " + ex.Message, false);
        }
    }

    private static string? FindJavaOnPath()
    {
        var pathEnv = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var segment in pathEnv.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try
            {
                var dir = Environment.ExpandEnvironmentVariables(segment.Trim().Trim('"'));
                if (string.IsNullOrWhiteSpace(dir)) continue;
                var candidate = Path.Combine(dir, "java.exe");
                if (File.Exists(candidate)) return candidate;
            }
            catch { }
        }

        // Common Java locations are only fallbacks; PATH remains the primary source.
        var roots = new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
        };
        foreach (var root in roots.Where(x => !string.IsNullOrWhiteSpace(x)))
        {
            try
            {
                var javaRoot = Path.Combine(root, "Java");
                if (Directory.Exists(javaRoot))
                {
                    var candidate = Directory.GetFiles(javaRoot, "java.exe", SearchOption.AllDirectories).FirstOrDefault();
                    if (candidate != null) return candidate;
                }
            }
            catch { }
        }

        return null;
    }

    private void SetJavaResult(string message, bool success)
    {
        if (javaResult != null && !javaResult.IsDisposed)
            javaResult.Text = message;
        status.Text = success ? "● Java 检测成功" : "● Java 检测未成功";
        if (!success)
            ShowNotice(message);
    }

    private Panel NewCard() => new() {
        Dock = DockStyle.Fill, BackColor = Card, Padding = new Padding(24),
        AutoScroll = true, Margin = new Padding(0, 0, 0, 12)
    };
    private Label Heading(string text) => new() {
        Text = text, Dock = DockStyle.Top, Height = 64,
        Font = new Font("Microsoft YaHei UI", 17F, FontStyle.Bold, GraphicsUnit.Point),
        ForeColor = Color.White, TextAlign = ContentAlignment.MiddleLeft,
        AutoEllipsis = true, Margin = new Padding(0, 0, 0, 12), Padding = new Padding(0, 0, 0, 8)
    };
    private Label FieldLabel(string text) => new() { Text = text, Dock = DockStyle.Top, Height = 30, ForeColor = TextMuted, Padding = new Padding(0, 6, 0, 0) };
    private TextBox NewTextBox(string placeholder) => new() { Text = placeholder, Dock = DockStyle.Top, Height = 38, BackColor = Color.FromArgb(17, 22, 32), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point), Margin = new Padding(0, 0, 0, 12) };

    private Control InfoCard(string title, string text)
    {
        var p = NewCard();
        p.Margin = new Padding(0, 0, 14, 0);
        p.Controls.Add(new Label { Text = title, Dock = DockStyle.Top, Height = 42, Font = new Font("Microsoft YaHei UI", 14F, FontStyle.Bold, GraphicsUnit.Point), ForeColor = Color.White });
        p.Controls.Add(new Label {
            Text = text, Dock = DockStyle.Fill, Font = new Font("Microsoft YaHei UI", 10F, FontStyle.Regular, GraphicsUnit.Point),
            ForeColor = TextMuted, AutoSize = false, UseMnemonic = false, Padding = new Padding(0, 8, 0, 0)
        });
        return p;
    }

    private void AddActionCard(TableLayoutPanel parent, int col, string title, string description, string action, EventHandler handler)
    {
        var p = NewCard();
        p.Margin = new Padding(0, 0, 10, 0);
        p.Padding = new Padding(18, 16, 18, 16);
        parent.Controls.Add(p, col, 0);
        p.Controls.Add(new Label {
            Text = title, Dock = DockStyle.Top, Height = 42, AutoEllipsis = true,
            Font = new Font("Microsoft YaHei UI", 13F, FontStyle.Bold, GraphicsUnit.Point),
            ForeColor = Color.White, TextAlign = ContentAlignment.MiddleLeft
        });
        p.Controls.Add(new Label {
            Text = description, Dock = DockStyle.Top, Height = 42, AutoEllipsis = true,
            ForeColor = TextMuted, Font = new Font("Microsoft YaHei UI", 9F, FontStyle.Regular, GraphicsUnit.Point),
            TextAlign = ContentAlignment.MiddleLeft
        });
        var b = MakeButton(action, Blue, 145);
        b.Dock = DockStyle.Bottom;
        b.Click += handler;
        p.Controls.Add(b);
    }

    private Button MakeButton(string text, Color color, int width)
    {
        var font = new Font("Microsoft YaHei UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
        var measuredWidth = TextRenderer.MeasureText(text, font).Width + 36;
        var actualWidth = Math.Max(width, Math.Min(360, measuredWidth));
        return new Button
        {
            Text = text,
            Width = actualWidth,
            Height = 52,
            MinimumSize = new Size(Math.Max(width, 120), 48),
            AutoSize = false,
            BackColor = color,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = font,
            Cursor = Cursors.Hand,
            Margin = new Padding(0, 8, 10, 8),
            Padding = new Padding(12, 8, 12, 8),
            AutoEllipsis = false,
            TextAlign = ContentAlignment.MiddleCenter
        };
    }

    private void ShowNotice(string text) => MessageBox.Show(this, text, "SCUL", MessageBoxButtons.OK, MessageBoxIcon.Information);
    private static void OpenUrl(string url)
    {
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
        catch { }
    }
    private static void OpenPath(string path)
    {
        try { if (Directory.Exists(path)) Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
        catch { }
    }

    private sealed class GameInstance
    {
        public string Name { get; set; } = "";
        public string Path { get; set; } = "";
        public DateTime AddedAt { get; set; }
        public string Display => $"{Name}  —  {Path}";
        public override string ToString() => Display;
    }

    private sealed class HeroPanel : Panel
    {
        public HeroPanel() { DoubleBuffered = true; BackColor = Card; MinimumSize = new Size(0, 120); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (ClientSize.Width <= 0 || ClientSize.Height <= 0) return;

            var g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var bounds = ClientRectangle;
            using (var bg = new System.Drawing.Drawing2D.LinearGradientBrush(
                bounds, Color.FromArgb(27, 48, 79), Color.FromArgb(48, 34, 78), 15f))
                g.FillRectangle(bg, bounds);

            float dpiScale = Math.Max(1f, DeviceDpi / 96f);
            float availableHeight = ClientSize.Height;
            float baseTitleSize = Math.Clamp(availableHeight / (dpiScale * 4.2f), 18f, 27f);
            using var title = new Font("Microsoft YaHei UI", baseTitleSize, FontStyle.Bold, GraphicsUnit.Point);
            using var sub = new Font("Microsoft YaHei UI", Math.Clamp(baseTitleSize * 0.42f, 9f, 12f), FontStyle.Regular, GraphicsUnit.Point);
            using var small = new Font("Microsoft YaHei UI", Math.Clamp(baseTitleSize * 0.32f, 8f, 9.5f), FontStyle.Bold, GraphicsUnit.Point);
            using var white = new SolidBrush(Color.White);
            using var muted = new SolidBrush(Color.FromArgb(195, 213, 239));
            using var blue = new SolidBrush(Color.FromArgb(135, 202, 255));

            float left = 22f * dpiScale;
            float top = Math.Max(8f * dpiScale, availableHeight * 0.10f);
            var titleRect = new RectangleF(left, top, Math.Max(20, ClientSize.Width - left * 2), availableHeight * 0.48f);
            var titleFormat = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap, LineAlignment = StringAlignment.Near };
            g.DrawString("开启你的下一段冒险", title, white, titleRect, titleFormat);

            float subY = Math.Min(availableHeight * 0.66f, top + title.GetHeight(g) + 3f * dpiScale);
            var subRect = new RectangleF(left + 1, subY, Math.Max(20, ClientSize.Width - left * 2), Math.Max(12, availableHeight - subY - 22f * dpiScale));
            var subFormat = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap };
            g.DrawString("更清晰地管理游戏实例、Java 环境与服务器。", sub, muted, subRect, subFormat);
            g.DrawString("SUPER CRAFT ULTIMATE LAUNCHER", small, blue,
                new RectangleF(left + 1, availableHeight - small.GetHeight(g) - 5f * dpiScale,
                Math.Max(20, ClientSize.Width - left * 2), small.GetHeight(g) + 2f), subFormat);

            int maxDiameter = Math.Max(20, Math.Min((int)(190 * dpiScale), (int)(availableHeight + 20)));
            for (int i = 0; i < 5; i++)
            {
                int size = maxDiameter - i * (int)(20 * dpiScale);
                if (size <= 0) continue;
                using var pen = new Pen(Color.FromArgb(22, 130, 185, 255), Math.Max(1f, dpiScale * 0.5f));
                g.DrawEllipse(pen, ClientSize.Width - size - 14 * dpiScale, (ClientSize.Height - size) / 2, size, size);
            }
        }
    }
}
